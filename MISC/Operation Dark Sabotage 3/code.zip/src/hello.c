#include <stdio.h>

void print_hello() {
    printf("Oh! Nice to see a familiar face.\n");
}
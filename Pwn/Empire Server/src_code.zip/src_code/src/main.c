#include <stdio.h>
#include <stdlib.h>
#include <microhttpd.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>


#define GET     0
#define POST    1

#define NOT_FOUD                "<html><head><title>404</title></head><body>File not found</body></html>"
#define INTERNAL_SERVER_ERROR   "<html><head><title>500</title></head>Internal Server Error</html>"
#define METHOD_NOT_ALLOWED       "<html><head><title>405</title></head>Method Not Allowed</html>"

#define POSTBUFFERSIZE      512
#define USER                50
#define PASSWORD            300


const char *valide_url[3] = {"/", "/login", "/style.css"};
const char *valide_file[3] = {"www/index.html", "www/login.html", "www/style.css"};

const char *errorLogin = 
"<!DOCTYPE html>"
"<html lang=\"fr\">"
"<body>"
    "<div>"
        "<h1>Erreur de connexion pour <span style=\"color:red;\">%s</span></h1>"
        "<p>Invalide login/password</p>"
    "</div>"
"</body>"
"</html>";

struct connection_info_struct {
    int connectiontype;
    char user[USER];
    char password[PASSWORD];
    struct MHD_PostProcessor *postprocessor;
};

static int get_method(const char *method){
    if(!strcmp(method, MHD_HTTP_METHOD_GET))
        return GET;
    else if (!strcmp(method, MHD_HTTP_METHOD_POST))
        return POST;
    return -1;
}

static int valid_acess(const char *url){
    for(int i = 0; i < 3; i++){
        if(!strcmp(valide_url[i], url)) return i;
    }
    return -1;
}

static ssize_t file_reader (void *cls, uint64_t pos, char *buf, size_t max)
{
    FILE *file = cls;

    (void)  fseek (file, pos, SEEK_SET);
    return fread (buf, 1, max, file);
}

static void free_callback (void *cls)
{
    FILE *file = cls;
    fclose (file);
}

static int get_response(void *cls, struct MHD_Connection *connection, const char *url) {
    struct MHD_Response *response;
    int ret;
    FILE *file;
    struct stat buf;
    int access = valid_acess(url);
    if(access < 0) {
        response = MHD_create_response_from_buffer(strlen(NOT_FOUD), (void *)NOT_FOUD, MHD_RESPMEM_PERSISTENT);
        ret = MHD_queue_response(connection, MHD_HTTP_NOT_FOUND, response);
        MHD_destroy_response(response);
        return ret;
    }
    if (0 == stat(valide_file[access], &buf)) {
        file = fopen(valide_file[access], "rb");
    } else {
        file = NULL;
    }
    if (file == NULL) {
        response = MHD_create_response_from_buffer(strlen(INTERNAL_SERVER_ERROR), (void *)INTERNAL_SERVER_ERROR, MHD_RESPMEM_PERSISTENT);
        ret = MHD_queue_response(connection, MHD_HTTP_INTERNAL_SERVER_ERROR, response);
        MHD_destroy_response(response);
    } else {
        response = MHD_create_response_from_callback(buf.st_size, 32 * 1024, &file_reader, file, &free_callback);
        if (response == NULL) {
            fclose(file);
            return MHD_NO;
        }
        ret = MHD_queue_response(connection, MHD_HTTP_OK, response);
        MHD_destroy_response(response);
    }
    printf("GET %s\n", url);
    return ret;
}

int iterate_post(void *coninfo_cls, enum MHD_ValueKind kind, const char *key,
                        const char *filename, const char *content_type,
                        const char *transfer_encoding, const char *data, uint64_t off,
                        size_t size) {
    struct connection_info_struct *con_info = coninfo_cls;
    if (0 == strcmp(key, "user")) {
        if ((size > 0) && (size <= USER)) {
            
            snprintf(con_info->user, USER, data);
        } else
            con_info->user[0] = '\0';
        return MHD_YES;
    } else if(0 == strcmp(key, "password")) {
        if ((size > 0) && (size <= PASSWORD)) {
            
            snprintf(con_info->password, PASSWORD, data);
        } else
            con_info->password[0] = '\0';
        return MHD_YES;
    }

    return MHD_YES;
}

static void request_completed(void *cls, struct MHD_Connection *connection,
                              void **con_cls, enum MHD_RequestTerminationCode toe) {
    struct connection_info_struct *con_info = *con_cls;

    if (NULL == con_info)
        return;

    if (con_info->connectiontype == POST) {
        if (con_info->postprocessor) {
            MHD_destroy_post_processor(con_info->postprocessor);
        }
    }

    free(con_info);
    *con_cls = NULL;
}

static int verify_account(char *user, char *password){
    char account[200];
    int key[13] = {0x8, 0x8, 0x2, 0x1f, 0xb, 0x1d, 0x18, 0x20, 0x16, 0x5, 0x19, 0x17, 0x16};
    char *valide = "IloveMyServer";

    strcpy(account, user);
    strcat(account, password);
    if(strlen(account)!=13)
        return -1;
    for(int i = 0; i < 13; i++){
        if((account[i]^key[i]) != valide[i])
            return -1;
    }
    return 0;
}

static int post_response(void *cls, struct MHD_Connection *connection, struct connection_info_struct *con_info) {
    struct MHD_Response *response;
    int ret;
    char page[512];
    FILE *file;
    struct stat buf;

    printf("POST /login %s %s\n", con_info->user, con_info->password);
    if(verify_account(con_info->user, con_info->password)){
        snprintf(page, 512, errorLogin, con_info->user);
        response = MHD_create_response_from_buffer(strlen(page), (void *)page, MHD_RESPMEM_PERSISTENT);
        ret = MHD_queue_response(connection, MHD_HTTP_OK, response);
        MHD_destroy_response(response);
        
    }else{
        stat("www/admin.html", &buf);
        file = fopen("www/admin.html", "rb");
        if (file == NULL) {
            response = MHD_create_response_from_buffer(strlen(INTERNAL_SERVER_ERROR), (void *)INTERNAL_SERVER_ERROR,  MHD_RESPMEM_PERSISTENT);
            ret = MHD_queue_response(connection, MHD_HTTP_INTERNAL_SERVER_ERROR, response);
            MHD_destroy_response(response);
        } else {
            response = MHD_create_response_from_callback(buf.st_size, 32 * 1024, &file_reader, file, &free_callback);
            if (response == NULL) {
                fclose(file);
                return MHD_NO;
            }
            ret = MHD_queue_response(connection, MHD_HTTP_OK, response);
            MHD_destroy_response(response);
        }
    }
    return ret;
}

static int answer_to_connection(void *cls, struct MHD_Connection *connection, const char *url, const char *method, const char *version, const char *upload_data, size_t *upload_data_size, void **ptr) {
    static int aptr;
    struct connection_info_struct *con_info;
    struct MHD_Response *response;
    int ret;

    switch (get_method(method))
    {
    case GET:
        if (&aptr != *ptr){
            *ptr = &aptr;
            return MHD_YES;
        }
        *ptr = NULL;
        return get_response(cls, connection, url);

    case POST:
        if (NULL == *ptr) {
            con_info = malloc(sizeof(struct connection_info_struct));
            if (NULL == con_info) 
                return MHD_NO;
            if(strcmp(url, "/login")){
                free(con_info);
                response = MHD_create_response_from_buffer(strlen(METHOD_NOT_ALLOWED), (void *)METHOD_NOT_ALLOWED, MHD_RESPMEM_PERSISTENT);
                ret = MHD_queue_response(connection, MHD_HTTP_METHOD_NOT_ALLOWED, response);
                MHD_destroy_response(response);
                return ret;
            }
            con_info->user[0] = '\0';
            con_info->password[0] = '\0';
            con_info->postprocessor = MHD_create_post_processor(connection, POSTBUFFERSIZE, iterate_post, (void *)con_info);
            if (NULL == con_info->postprocessor) {
                free(con_info);
                return MHD_NO;
            }
            con_info->connectiontype = POST;
            *ptr = (void *)con_info;
            return MHD_YES;
        }
        con_info = *ptr;
        if (*upload_data_size != 0) {
            MHD_post_process(con_info->postprocessor, upload_data, *upload_data_size);
            *upload_data_size = 0;
            
            return MHD_YES;
        }else if ('\0' != con_info->user[0] && con_info->password[0] != '\0'){
            return post_response(cls, connection, con_info);
        }
        break;
    default:
        return MHD_NO;
    }
    return MHD_NO;
}

int main (int argc, char *const *argv)
{
    struct MHD_Daemon *d;

    d = MHD_start_daemon(MHD_USE_SELECT_INTERNALLY, 9999, NULL, NULL, &answer_to_connection, NULL, MHD_OPTION_NOTIFY_COMPLETED, request_completed, NULL, MHD_OPTION_END);
    if (d == NULL)
        return 1;
    while(1) sleep(3600);
    MHD_stop_daemon (d);
    return 0;
}
